# Explosive Radius for RimWorld

This is a little QoL mod that displays explosion radius on all explosives on selection and placing.

[<img src="https://i.imgur.com/N8E4pyP.png" height="50">](https://steamcommunity.com/workshop/filedetails/?id=2729671309)

Feedback is welcome. Please leave a comment if you spot any issues or have any suggestions! Hope you like it.


![](./About/Preview.png)
![](./About/Preview2.png)